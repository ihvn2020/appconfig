#!/bin/bash 
java -jar EHealthDataPump8.3.jar

